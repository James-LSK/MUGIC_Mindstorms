#!/usr/bin/env pybricks-micropython
import time
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile


# This program requires LEGO EV3 MicroPython v2.0 or higher.
# Click "Open user guide" on the EV3 extension tab for more information.


# Create your objects here.
ev3 = EV3Brick()
left_motor = Motor(Port.A)
right_motor = Motor(Port.D)
gyro = GyroSensor(Port.S2)
drive_base = DriveBase(left_motor, right_motor, wheel_diameter=55.5, axle_track=104)

# 定义一个简单的函数来保持平衡
def balance():
    gyro_value = gyro.speed()
    if gyro_value > 1:
        correction = -gyro_value
    elif gyro_value < -1:
        correction = -gyro_value
    else:
        correction = 0
    return correction

# 让机器人保持平衡，向前走两秒
start_time = time.time()
while time.time() - start_time < 2:
    correction = balance()
    drive_base.drive(30 + correction, 0)
    wait(10)

# 让机器人保持平衡，向左走三秒
start_time = time.time()
while time.time() - start_time < 3:
    correction = balance()
    drive_base.drive(30 + correction, -100)
    wait(10)

# 停止机器人
drive_base.stop()